import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

void main() {
  runApp(const OCRApp());
}

class OCRApp extends StatelessWidget {
  const OCRApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'OCR รวมข้อความ',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1A73E8),
          brightness: Brightness.light,
        ),
        useMaterial3: true,
        fontFamily: 'Krub',
      ),
      home: const OCRHomePage(),
    );
  }
}

class ImageOCRResult {
  final File image;
  final String text;
  final bool isProcessing;

  ImageOCRResult({
    required this.image,
    required this.text,
    this.isProcessing = false,
  });

  ImageOCRResult copyWith({String? text, bool? isProcessing}) {
    return ImageOCRResult(
      image: image,
      text: text ?? this.text,
      isProcessing: isProcessing ?? this.isProcessing,
    );
  }
}

class OCRHomePage extends StatefulWidget {
  const OCRHomePage({super.key});

  @override
  State<OCRHomePage> createState() => _OCRHomePageState();
}

class _OCRHomePageState extends State<OCRHomePage> with TickerProviderStateMixin {
  final List<ImageOCRResult> _results = [];
  final ImagePicker _picker = ImagePicker();
  late AnimationController _fabController;
  bool _isCopied = false;

  @override
  void initState() {
    super.initState();
    _fabController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 200),
    );
  }

  @override
  void dispose() {
    _fabController.dispose();
    super.dispose();
  }

  String get _combinedText {
    return _results
        .where((r) => r.text.isNotEmpty && !r.isProcessing)
        .map((r) => r.text.trim())
        .join('\n\n');
  }

  Future<void> _pickImages(ImageSource source) async {
    try {
      if (source == ImageSource.gallery) {
        final List<XFile> images = await _picker.pickMultiImage(
          imageQuality: 100,
        );
        if (images.isEmpty) return;
        for (final img in images) {
          await _addAndProcessImage(File(img.path));
        }
      } else {
        final XFile? image = await _picker.pickImage(
          source: source,
          imageQuality: 100,
        );
        if (image == null) return;
        await _addAndProcessImage(File(image.path));
      }
    } catch (e) {
      _showSnackBar('เกิดข้อผิดพลาด: $e', isError: true);
    }
  }

  Future<void> _addAndProcessImage(File imageFile) async {
    final index = _results.length;
    setState(() {
      _results.add(ImageOCRResult(
        image: imageFile,
        text: '',
        isProcessing: true,
      ));
    });

    final text = await _performOCR(imageFile);
    setState(() {
      _results[index] = _results[index].copyWith(
        text: text,
        isProcessing: false,
      );
    });
  }

  Future<String> _performOCR(File imageFile) async {
    try {
      final inputImage = InputImage.fromFile(imageFile);
      final textRecognizer = TextRecognizer(
        script: TextRecognitionScript.latin,
      );
      final RecognizedText recognizedText =
          await textRecognizer.processImage(inputImage);
      await textRecognizer.close();

      // รวมข้อความจากทุก block
      final buffer = StringBuffer();
      for (final block in recognizedText.blocks) {
        for (final line in block.lines) {
          buffer.writeln(line.text);
        }
        buffer.writeln();
      }
      return buffer.toString().trim();
    } catch (e) {
      return '[ไม่สามารถอ่านข้อความได้: $e]';
    }
  }

  Future<void> _reprocessImage(int index) async {
    setState(() {
      _results[index] = _results[index].copyWith(isProcessing: true, text: '');
    });
    final text = await _performOCR(_results[index].image);
    setState(() {
      _results[index] = _results[index].copyWith(
        text: text,
        isProcessing: false,
      );
    });
  }

  void _removeImage(int index) {
    setState(() {
      _results.removeAt(index);
    });
  }

  void _editText(int index) {
    final controller = TextEditingController(text: _results[index].text);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('แก้ไขข้อความ #${index + 1}',
            style: const TextStyle(fontFamily: 'Krub')),
        content: TextField(
          controller: controller,
          maxLines: 8,
          decoration: const InputDecoration(
            border: OutlineInputBorder(),
            hintText: 'ข้อความจาก OCR...',
          ),
          style: const TextStyle(fontFamily: 'Krub', fontSize: 14),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('ยกเลิก', style: TextStyle(fontFamily: 'Krub')),
          ),
          FilledButton(
            onPressed: () {
              setState(() {
                _results[index] =
                    _results[index].copyWith(text: controller.text);
              });
              Navigator.pop(ctx);
            },
            child: const Text('บันทึก', style: TextStyle(fontFamily: 'Krub')),
          ),
        ],
      ),
    );
  }

  Future<void> _copyAll() async {
    if (_combinedText.isEmpty) {
      _showSnackBar('ยังไม่มีข้อความให้คัดลอก');
      return;
    }
    await Clipboard.setData(ClipboardData(text: _combinedText));
    setState(() => _isCopied = true);
    _showSnackBar('คัดลอกข้อความทั้งหมดแล้ว ✓');
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) setState(() => _isCopied = false);
    });
  }

  void _clearAll() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('ล้างข้อมูลทั้งหมด',
            style: TextStyle(fontFamily: 'Krub')),
        content: const Text('ต้องการล้างรูปภาพและข้อความทั้งหมดใช่ไหม?',
            style: TextStyle(fontFamily: 'Krub')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('ยกเลิก', style: TextStyle(fontFamily: 'Krub')),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
                backgroundColor: Colors.red.shade600),
            onPressed: () {
              setState(() => _results.clear());
              Navigator.pop(ctx);
            },
            child: const Text('ล้างทั้งหมด',
                style: TextStyle(fontFamily: 'Krub')),
          ),
        ],
      ),
    );
  }

  void _showSnackBar(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(fontFamily: 'Krub')),
        backgroundColor: isError ? Colors.red.shade600 : Colors.green.shade600,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  void _showAddOptions() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey.shade300,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 20),
            Text(
              'เพิ่มรูปภาพ',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                fontFamily: 'Krub',
                color: Colors.grey.shade800,
              ),
            ),
            const SizedBox(height: 20),
            _OptionTile(
              icon: Icons.photo_library_rounded,
              label: 'เลือกจากแกลเลอรี่',
              subtitle: 'เลือกได้หลายรูปพร้อมกัน',
              color: const Color(0xFF1A73E8),
              onTap: () {
                Navigator.pop(ctx);
                _pickImages(ImageSource.gallery);
              },
            ),
            const SizedBox(height: 12),
            _OptionTile(
              icon: Icons.camera_alt_rounded,
              label: 'ถ่ายรูปใหม่',
              subtitle: 'ใช้กล้องถ่ายเอกสาร',
              color: const Color(0xFF0F9D58),
              onTap: () {
                Navigator.pop(ctx);
                _pickImages(ImageSource.camera);
              },
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        title: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF1A73E8), Color(0xFF0F9D58)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.document_scanner_rounded,
                  color: Colors.white, size: 20),
            ),
            const SizedBox(width: 10),
            const Text(
              'OCR รวมข้อความ',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                fontFamily: 'Krub',
                color: Color(0xFF1A1A2E),
              ),
            ),
          ],
        ),
        actions: [
          if (_results.isNotEmpty)
            IconButton(
              onPressed: _clearAll,
              icon: const Icon(Icons.delete_sweep_rounded),
              color: Colors.red.shade400,
              tooltip: 'ล้างทั้งหมด',
            ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: const Color(0xFFE8EAED), height: 1),
        ),
      ),
      body: _results.isEmpty ? _buildEmptyState() : _buildContent(),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showAddOptions,
        backgroundColor: const Color(0xFF1A73E8),
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add_photo_alternate_rounded),
        label: const Text('เพิ่มรูป',
            style: TextStyle(fontFamily: 'Krub', fontWeight: FontWeight.w600)),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 120,
              height: 120,
              decoration: BoxDecoration(
                color: const Color(0xFF1A73E8).withOpacity(0.08),
                borderRadius: BorderRadius.circular(32),
              ),
              child: const Icon(
                Icons.document_scanner_rounded,
                size: 56,
                color: Color(0xFF1A73E8),
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              'เพิ่มรูปภาพเพื่อเริ่มต้น',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w700,
                fontFamily: 'Krub',
                color: Color(0xFF1A1A2E),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'กดปุ่ม "เพิ่มรูป" ด้านล่าง\nระบบจะอ่านข้อความจากรูปโดยอัตโนมัติ',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                fontFamily: 'Krub',
                color: Colors.grey.shade500,
                height: 1.6,
              ),
            ),
            const SizedBox(height: 32),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _FeatureChip(icon: Icons.auto_fix_high_rounded, label: 'ML Kit OCR'),
                const SizedBox(width: 8),
                _FeatureChip(icon: Icons.layers_rounded, label: 'หลายรูป'),
                const SizedBox(width: 8),
                _FeatureChip(icon: Icons.copy_rounded, label: 'Copy ทันที'),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContent() {
    return Column(
      children: [
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            itemCount: _results.length,
            itemBuilder: (ctx, i) => _ImageCard(
              index: i,
              result: _results[i],
              onEdit: () => _editText(i),
              onDelete: () => _removeImage(i),
              onReprocess: () => _reprocessImage(i),
            ),
          ),
        ),
        _buildBottomBar(),
      ],
    );
  }

  Widget _buildBottomBar() {
    final hasText = _combinedText.isNotEmpty;
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 16,
            offset: const Offset(0, -4),
          ),
        ],
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              Icon(Icons.text_snippet_rounded,
                  size: 16, color: Colors.grey.shade500),
              const SizedBox(width: 6),
              Text(
                '${_results.where((r) => !r.isProcessing).length} รูป · ${_combinedText.length} ตัวอักษร',
                style: TextStyle(
                  fontSize: 12,
                  fontFamily: 'Krub',
                  color: Colors.grey.shade500,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 52,
            child: FilledButton.icon(
              onPressed: hasText ? _copyAll : null,
              style: FilledButton.styleFrom(
                backgroundColor:
                    _isCopied ? Colors.green.shade600 : const Color(0xFF1A73E8),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
              ),
              icon: Icon(
                _isCopied ? Icons.check_rounded : Icons.copy_rounded,
                size: 20,
              ),
              label: Text(
                _isCopied ? 'คัดลอกแล้ว!' : 'คัดลอกข้อความทั้งหมด',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  fontFamily: 'Krub',
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ImageCard extends StatelessWidget {
  final int index;
  final ImageOCRResult result;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final VoidCallback onReprocess;

  const _ImageCard({
    required this.index,
    required this.result,
    required this.onEdit,
    required this.onDelete,
    required this.onReprocess,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 8, 0),
            child: Row(
              children: [
                Container(
                  width: 28,
                  height: 28,
                  decoration: BoxDecoration(
                    color: const Color(0xFF1A73E8),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Center(
                    child: Text(
                      '${index + 1}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        fontFamily: 'Krub',
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'รูปที่ ${index + 1}',
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      fontFamily: 'Krub',
                      color: Color(0xFF1A1A2E),
                    ),
                  ),
                ),
                IconButton(
                  onPressed: onReprocess,
                  icon: const Icon(Icons.refresh_rounded, size: 20),
                  color: Colors.blue.shade400,
                  tooltip: 'อ่านใหม่',
                ),
                IconButton(
                  onPressed: onEdit,
                  icon: const Icon(Icons.edit_rounded, size: 20),
                  color: Colors.orange.shade400,
                  tooltip: 'แก้ไข',
                ),
                IconButton(
                  onPressed: onDelete,
                  icon: const Icon(Icons.close_rounded, size: 20),
                  color: Colors.red.shade400,
                  tooltip: 'ลบ',
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          // Image preview
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.file(
                result.image,
                height: 120,
                width: double.infinity,
                fit: BoxFit.cover,
              ),
            ),
          ),
          const SizedBox(height: 10),
          // Text result
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFF8F9FA),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFFE8EAED)),
              ),
              child: result.isProcessing
                  ? Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: const Color(0xFF1A73E8),
                          ),
                        ),
                        const SizedBox(width: 10),
                        const Text(
                          'กำลังอ่านข้อความ...',
                          style: TextStyle(
                            fontFamily: 'Krub',
                            fontSize: 13,
                            color: Color(0xFF1A73E8),
                          ),
                        ),
                      ],
                    )
                  : result.text.isEmpty
                      ? Text(
                          'ไม่พบข้อความในรูป',
                          style: TextStyle(
                            fontFamily: 'Krub',
                            fontSize: 13,
                            color: Colors.grey.shade400,
                            fontStyle: FontStyle.italic,
                          ),
                        )
                      : Text(
                          result.text,
                          style: const TextStyle(
                            fontFamily: 'Krub',
                            fontSize: 13,
                            color: Color(0xFF3C4043),
                            height: 1.6,
                          ),
                        ),
            ),
          ),
        ],
      ),
    );
  }
}

class _OptionTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  const _OptionTile({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: color.withOpacity(0.06),
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: color, size: 22),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(label,
                        style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'Krub',
                            color: color)),
                    Text(subtitle,
                        style: TextStyle(
                            fontSize: 12,
                            fontFamily: 'Krub',
                            color: Colors.grey.shade500)),
                  ],
                ),
              ),
              Icon(Icons.arrow_forward_ios_rounded,
                  size: 14, color: Colors.grey.shade400),
            ],
          ),
        ),
      ),
    );
  }
}

class _FeatureChip extends StatelessWidget {
  final IconData icon;
  final String label;

  const _FeatureChip({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFF1A73E8).withOpacity(0.08),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 13, color: const Color(0xFF1A73E8)),
          const SizedBox(width: 5),
          Text(label,
              style: const TextStyle(
                  fontSize: 11,
                  fontFamily: 'Krub',
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF1A73E8))),
        ],
      ),
    );
  }
}
