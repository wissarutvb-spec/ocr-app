# OCR รวมข้อความ 📷→📝

Flutter Android App อ่านข้อความจากรูปภาพด้วย Google ML Kit และรวมข้อความจากหลายรูปเป็นข้อความเดียว

---

## ✨ ฟีเจอร์

- 📸 **เลือกหลายรูปพร้อมกัน** จากแกลเลอรี่ หรือถ่ายจากกล้อง
- 🤖 **OCR แม่นยำ** ด้วย Google ML Kit (ทำงานแบบ offline)
- ✏️ **แก้ไขข้อความ** ที่อ่านได้ก่อน copy
- 🔄 **อ่านใหม่** กรณีผลลัพธ์ไม่ถูกต้อง
- 📋 **Copy ข้อความทั้งหมด** ด้วยปุ่มเดียว
- 🈳 **ฟอนต์ภาษาไทย** Krub

---

## 📱 วิธีติดตั้งและ Build APK

### วิธีที่ 1: GitHub Actions (แนะนำ — ทำจากมือถือได้)

1. **Fork หรือ Push โค้ดขึ้น GitHub**
   - ไปที่ [github.com](https://github.com) → สร้าง repository ใหม่
   - Upload ไฟล์ทั้งหมดในโฟลเดอร์นี้

2. **รัน GitHub Actions**
   - ไปที่ tab **Actions** ใน repository
   - คลิก **"Build APK"** → **"Run workflow"**
   - รอประมาณ 5–8 นาที

3. **ดาวน์โหลด APK**
   - เมื่อ build เสร็จ → คลิก run นั้น
   - เลื่อนลงไปที่ **Artifacts** → ดาวน์โหลด `ocr-combine-text-apk.zip`
   - แตกไฟล์ → ได้ `app-release.apk`

4. **ติดตั้งบน Android**
   - เปิด Settings → Security → เปิด "Unknown sources"
   - เปิดไฟล์ APK → Install

---

### วิธีที่ 2: Codemagic.io

1. ไปที่ [codemagic.io](https://codemagic.io) → Sign in ด้วย GitHub
2. เลือก repository นี้
3. เลือก **Flutter App** → build workflow
4. กด **Start new build**
5. เมื่อสำเร็จ → ดาวน์โหลด APK

---

## 📂 โครงสร้างโปรเจกต์

```
ocr_combine_text/
├── lib/
│   └── main.dart          ← โค้ดหลักทั้งหมด
├── android/
│   └── app/
│       ├── build.gradle
│       └── src/main/
│           ├── AndroidManifest.xml
│           └── res/xml/file_paths.xml
├── assets/
│   └── fonts/             ← Krub font (ดาวน์โหลดอัตโนมัติตอน build)
├── .github/
│   └── workflows/
│       └── build_apk.yml  ← GitHub Actions
└── pubspec.yaml
```

---

## 🔧 Dependencies

| Package | เวอร์ชัน | ใช้ทำอะไร |
|---------|---------|-----------|
| `google_mlkit_text_recognition` | ^0.13.0 | OCR อ่านข้อความ |
| `image_picker` | ^1.1.2 | เลือก/ถ่ายรูป |

---

## 📝 หมายเหตุ

- **minSdkVersion 23** (Android 6.0+)
- ML Kit OCR ทำงาน **offline** หลังจากดาวน์โหลดโมเดลครั้งแรก
- รองรับข้อความ **ภาษาไทยและภาษาอังกฤษ**
- ขนาด APK ประมาณ **20–30 MB**
